# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(p99-latency src/p99-latency.cpp)
set_property(TARGET p99-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(p99-latency lionss pthread)

add_executable(clang-trunk src/clang-trunk.cpp)
set_property(TARGET clang-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-trunk lionss pthread)

add_executable(vendored-check src/vendored-check.cpp)
set_property(TARGET vendored-check PROPERTY CXX_STANDARD 11)
target_link_libraries(vendored-check lionss pthread)

add_executable(address-sanitizer src/address-sanitizer.cpp)
set_property(TARGET address-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(address-sanitizer lionss pthread)

add_executable(in-source-guard src/in-source-guard.cpp)
set_property(TARGET in-source-guard PROPERTY CXX_STANDARD 11)
target_link_libraries(in-source-guard lionss pthread)

add_executable(submodule-sync src/submodule-sync.cpp)
set_property(TARGET submodule-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(submodule-sync lionss pthread)

add_executable(gcc-13 src/gcc-13.cpp)
set_property(TARGET gcc-13 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-13 lionss pthread)

add_executable(unreachable-code src/unreachable-code.cpp)
set_property(TARGET unreachable-code PROPERTY CXX_STANDARD 11)
target_link_libraries(unreachable-code lionss pthread)

add_executable(structure-aware-fuzz src/structure-aware-fuzz.cpp)
set_property(TARGET structure-aware-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(structure-aware-fuzz lionss pthread)

add_executable(makefiles-build src/makefiles-build.cpp)
set_property(TARGET makefiles-build PROPERTY CXX_STANDARD 11)
target_link_libraries(makefiles-build lionss pthread)

add_executable(codeblock-run src/codeblock-run.cpp)
set_property(TARGET codeblock-run PROPERTY CXX_STANDARD 11)
target_link_libraries(codeblock-run lionss pthread)

add_executable(lto-build src/lto-build.cpp)
set_property(TARGET lto-build PROPERTY CXX_STANDARD 11)
target_link_libraries(lto-build lionss pthread)

add_executable(shadow-call-stack src/shadow-call-stack.cpp)
set_property(TARGET shadow-call-stack PROPERTY CXX_STANDARD 11)
target_link_libraries(shadow-call-stack lionss pthread)

add_executable(debug-info-check src/debug-info-check.cpp)
set_property(TARGET debug-info-check PROPERTY CXX_STANDARD 11)
target_link_libraries(debug-info-check lionss pthread)

add_executable(release-notes src/release-notes.cpp)
set_property(TARGET release-notes PROPERTY CXX_STANDARD 11)
target_link_libraries(release-notes lionss pthread)

add_executable(license-audit src/license-audit.cpp)
set_property(TARGET license-audit PROPERTY CXX_STANDARD 11)
target_link_libraries(license-audit lionss pthread)

add_executable(package-appimage src/package-appimage.cpp)
set_property(TARGET package-appimage PROPERTY CXX_STANDARD 11)
target_link_libraries(package-appimage lionss pthread)

add_executable(oss-fuzz-sync src/oss-fuzz-sync.cpp)
set_property(TARGET oss-fuzz-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(oss-fuzz-sync lionss pthread)

add_executable(nvcc-build src/nvcc-build.cpp)
set_property(TARGET nvcc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nvcc-build lionss pthread)

add_executable(valgrind-memcheck src/valgrind-memcheck.cpp)
set_property(TARGET valgrind-memcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-memcheck lionss pthread)

add_executable(branch-coverage src/branch-coverage.cpp)
set_property(TARGET branch-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(branch-coverage lionss pthread)

add_executable(hot-path-profile src/hot-path-profile.cpp)
set_property(TARGET hot-path-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(hot-path-profile lionss pthread)

add_executable(undefined-sanitizer src/undefined-sanitizer.cpp)
set_property(TARGET undefined-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(undefined-sanitizer lionss pthread)

add_executable(scaling-bench src/scaling-bench.cpp)
set_property(TARGET scaling-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(scaling-bench lionss pthread)

add_executable(coverity-scan src/coverity-scan.cpp)
set_property(TARGET coverity-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(coverity-scan lionss pthread)

add_executable(signal-handling src/signal-handling.cpp)
set_property(TARGET signal-handling PROPERTY CXX_STANDARD 11)
target_link_libraries(signal-handling lionss pthread)

add_executable(safestack src/safestack.cpp)
set_property(TARGET safestack PROPERTY CXX_STANDARD 11)
target_link_libraries(safestack lionss pthread)

add_executable(permissions-audit src/permissions-audit.cpp)
set_property(TARGET permissions-audit PROPERTY CXX_STANDARD 11)
target_link_libraries(permissions-audit lionss pthread)

add_executable(spdx-sbom src/spdx-sbom.cpp)
set_property(TARGET spdx-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(spdx-sbom lionss pthread)

add_executable(split-dwarf src/split-dwarf.cpp)
set_property(TARGET split-dwarf PROPERTY CXX_STANDARD 11)
target_link_libraries(split-dwarf lionss pthread)

