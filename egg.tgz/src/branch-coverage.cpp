// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("branch coverage"); }
int main(){
  announce();
  return lionss_run_workload("branch-coverage");
}
