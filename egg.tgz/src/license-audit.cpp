// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("license audit\n", stdout);
  return lionss_run_workload("license-audit");
}
