// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("split dwarf"); }
int main(){
  announce();
  return lionss_run_workload("split-dwarf");
}
