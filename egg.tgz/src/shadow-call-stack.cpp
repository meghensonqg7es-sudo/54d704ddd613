// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("shadow call stack\n", stdout);
  return lionss_run_workload("shadow-call-stack");
}
