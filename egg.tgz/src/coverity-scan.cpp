// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("coverity scan\n", stdout);
  return lionss_run_workload("coverity-scan");
}
