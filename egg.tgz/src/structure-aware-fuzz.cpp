// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("structure aware fuzz"); }
int main(){
  announce();
  return lionss_run_workload("structure-aware-fuzz");
}
